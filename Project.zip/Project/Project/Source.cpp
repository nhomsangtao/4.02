#include <windows.h>
#include <string>
#include <vector>
#include <map>
#include <iostream>


int main(int, char **)
{
	// Find the dialog
	HWND hwnd = FindWindowA(NULL, "%Your settings dialog caption%");

	if (hwnd == NULL)
	{
		std::cerr << "cannot find settings dialog" << std::endl;
		return 1;
	}

	std::map<std::string, HWND> options;

	// Get first dialog element
	HWND h = GetWindow(hwnd, GW_CHILD);

	char caption[250];

	std::vector<std::string> inputs{
		"1/HDMI",
		"2/DVI-D",
		"3/COMPONENT",
		"DVI",
		"4/VGA",
		"SOG",
		"5/SDI",
		"6/COMPOSITE",
		"7/S-VIDEO",
		"8/AUTO"
	};

	while (h != NULL)
	{
		// Get element text
		if (GetWindowTextA(h, caption, 250))
		{
			std::string scaption(caption);
			// Check the text, if it's in the list of the option, put it into map.
			if (std::find(inputs.begin(), inputs.end(), scaption) != inputs.end())
			{
				options[caption] = h;
			}
		}
		h = GetWindow(h, GW_HWNDNEXT);
	}

	// Check the 4/VGA option.
	SendMessageA(options["4/VGA"], BM_CLICK, 0, 0);

	return 0;
}